﻿using System.ComponentModel.DataAnnotations;

namespace RaceDayAPI.Models
{
    public class Event
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public DateTime EventDate { get; set; }
        public string Location { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public int OrganiserId { get; set; }
        public decimal Distance { get; set; }
        public string EventType { get; set; } = string.Empty;
        public decimal EntryFee { get; set; }
    }
}